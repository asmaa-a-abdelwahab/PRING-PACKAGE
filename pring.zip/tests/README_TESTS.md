# PRING test strategy

This suite is organized to support publication, maintenance, and user adoption.

## What is covered

- **Fast offline tests** for parsing, normalization, query planning, graph transformation, I/O helpers, caching, and artifact writing.
- **CLI and integration tests** for `build`, `schema`, and `demo`, including plugin output persistence and SPARQL/REST mode selection.
- **Neo4j loader tests** that validate generated Cypher, schema validation, chunking, and key-mapping behavior without needing a live database.
- **Opt-in live smoke tests** for PubChem RDF REST and Neo4j to validate external integrations in release workflows.

## Default command

```bash
python -m pytest -q tests -m "not live and not neo4j"
```

## Run all offline publication checks with coverage

```bash
python -m pip install pytest-cov
python -m pytest -q tests -m "not live and not neo4j" --cov=pring --cov-report=term-missing
```

## Opt-in live checks

PubChem smoke test:

```bash
set PRING_RUN_LIVE=1
python -m pytest -q tests/live/test_live_smoke.py -m live
```

Neo4j smoke test:

```bash
set PRING_RUN_LIVE=1
set PRING_RUN_NEO4J=1
set NEO4J_URI=bolt://localhost:7687
set NEO4J_USER=neo4j
set NEO4J_PASSWORD=neo4j
python -m pytest -q tests/live/test_live_smoke.py -m neo4j
```

## Recommended release gate

A release candidate should satisfy all of these:

1. Offline suite passes on Windows and Linux.
2. Coverage remains stable or increases for `pring`, especially `cli`, `extract`, `io`, `neo4j`, and `utils`.
3. At least one live PubChem smoke test passes.
4. At least one live Neo4j smoke test passes.
5. Manual CLI smoke runs succeed for:
   - `demo`
   - small `build` from compounds
   - small `build` from targets
   - small `build` in `sparql` mode
