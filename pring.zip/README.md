# PRING

PRING builds an implementation-ready Neo4j knowledge graph from PubChem RDF for chemical–gene/protein interaction modeling, with a CYP450-focused workflow for thesis experiments.

See `PRING_RESOURCE_AND_RELEASE_NOTES.md` for low-resource commands, CLI flags, example CYP450 inputs, and plugin-data format.
