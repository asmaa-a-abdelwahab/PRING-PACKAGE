from __future__ import annotations

import argparse
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from pring.config import Settings, BuildCaps, BuildFlags
from pring.extract.query_plan import decide_mode, decide_scope, load_id_file, Mode, Scope
from pring.extract.pubchem_rdf_rest import PubChemRdfRestClient, PubChemRdfRestExtractor
from pring.extract.pubchem_sparql_mirror import SparqlMirrorClient, PubChemSparqlMirrorExtractor
from pring.extract.pubchem_core import PubChemRow, to_graph_records
from pring.neo4j.driver import Neo4jDriver
from pring.neo4j.loader import Neo4jLoader
from pring.plugins import load_plugins, normalize_plugin_list
from pring.utils import setup_logging, RunStore

log = logging.getLogger("pring")


def _parse_int_or_none(v: Optional[str]) -> Optional[int]:
    if v is None:
        return None
    v = str(v).strip()
    if v == "" or v.lower() == "none":
        return None
    return int(v)


def _fallback_worth_trying(exc: Exception) -> bool:
    msg = str(exc).lower()
    return any(token in msg for token in ("http get failed", "http post failed", "503", "504", "429", "thrott", "timed out", "timeout"))


def _collect_rows(extractor, scope: Scope, chem_ids: List[str], target_ids: List[str], settings: Settings, store: RunStore) -> List[PubChemRow]:
    rows: List[PubChemRow] = []
    if scope == Scope.intersection:
        iterator = extractor.iter_intersection_evidence(chem_ids, target_ids, caps=settings.caps, flags=settings.flags)
    elif scope == Scope.expand_from_targets:
        iterator = extractor.iter_expand_from_targets(target_ids, caps=settings.caps, flags=settings.flags)
    else:
        iterator = extractor.iter_expand_from_compounds(chem_ids, caps=settings.caps, flags=settings.flags)
    for d in iterator:
        rows.append(PubChemRow(kind=d["kind"], data=d["data"]))
        store.save_row(d["kind"], d["data"])
    return rows



def _add_shared_args(parser: argparse.ArgumentParser, *, default_suppress: bool = False) -> None:
    default = argparse.SUPPRESS if default_suppress else None

    parser.add_argument("--schema-dot", type=str, default=default, help="Path to Graphviz DOT schema (optional but recommended).")

    # Inputs
    parser.add_argument("--chem-ids", type=str, default=default, help="Text file of chemical IDs (CIDs; one per line).")
    parser.add_argument("--target-ids", type=str, default=default, help="Text file of target IDs (e.g., UniProt accessions or URIs; one per line).")

    # Mode/scope
    parser.add_argument("--mode", type=str, choices=[m.value for m in Mode], default=default,
                        help="rdf-rest (default), sparql (SPARQL mirror), or ftp (bulk; not implemented here).")
    parser.add_argument("--scope", type=str, choices=[s.value for s in Scope], default=default,
                        help="intersection|expand-from-targets|expand-from-compounds. Default depends on provided inputs.")

    # Neo4j
    parser.add_argument("--neo4j-uri", type=str, default=default)
    parser.add_argument("--neo4j-user", type=str, default=default)
    parser.add_argument("--neo4j-password", type=str, default=default)
    parser.add_argument("--neo4j-db", type=str, default=default)
    parser.add_argument("--load-neo4j", type=str, choices=["true", "false"], default=argparse.SUPPRESS if default_suppress else "true",
                        help="Whether to load extracted data into Neo4j (default: true). Set false to only save run artifacts.")

    # SPARQL mirror
    parser.add_argument("--sparql-endpoint", type=str, default=default,
                        help="SPARQL endpoint URL for mirror mode (default: https://idsm.elixir-czech.cz/sparql/endpoint/idsm).")
    parser.add_argument("--sparql-timeout-s", type=float, default=default, help="SPARQL HTTP timeout seconds.")

    # Flags
    parser.add_argument("--include-textmining", type=str, choices=["true", "false"], default=default)
    parser.add_argument("--include-optional-context", type=str, choices=["true", "false"], default=default)
    parser.add_argument("--include-endpoint-metadata", type=str, choices=["true", "false"], default=default,
                        help="Fetch endpoint label/value/unit/outcome metadata (default: true).")
    parser.add_argument("--include-endpoint-references", type=str, choices=["true", "false"], default=default,
                        help="Fetch endpoint reference links (default: false; often the most throttle-prone optional lookup).")
    parser.add_argument(
        "--taxid",
        type=str,
        default=default,
        help="Optional taxonomy filter. Examples: 9606 or TAXID9606 or 9606,10090."
    )

    # Caps (for Case B/C)
    parser.add_argument("--max-compounds-per-target", type=str, default=default)
    parser.add_argument("--max-targets-per-compound", type=str, default=default)
    parser.add_argument("--max-substances-per-compound", type=str, default=default)
    parser.add_argument("--max-measuregroups-per-target", type=str, default=default)
    parser.add_argument("--max-measuregroups-per-compound", type=str, default=default)
    parser.add_argument("--max-endpoints-per-pair", type=str, default=default)

    # Cache + runtime
    parser.add_argument("--cache-dir", type=str, default=default, help="Cache directory for downloads/HTTP responses.")
    parser.add_argument("--prefer-sparql-fallback", type=str, choices=["true", "false"], default=argparse.SUPPRESS if default_suppress else "true",
                        help="If RDF REST is throttled or unavailable, retry the build through the SPARQL mirror.")
    parser.add_argument("--rest-min-delay-s", type=float, default=default, help="Minimum spacing between RDF REST requests.")
    parser.add_argument("--rest-max-delay-s", type=float, default=default, help="Upper bound for adaptive RDF REST backoff.")
    parser.add_argument("--rest-honor-throttling", type=str, choices=["true", "false"], default=default,
                        help="Honor PubChem X-Throttling-Control and Retry-After headers (default: true).")
    parser.add_argument("--batch-size", type=int, default=default, help="Neo4j UNWIND batch size (default from Settings).")
    parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS if default_suppress else False, help="Plan + fetch (optional), but do not write to Neo4j.")

    # Output + logging
    parser.add_argument("--out-dir", type=str, default=argparse.SUPPRESS if default_suppress else "runs", help="Where to store run artifacts (logs, cached responses, extracted graph).")
    parser.add_argument("--run-id", type=str, default=default, help="Run identifier (default: timestamp).")
    parser.add_argument("--save-raw", type=str, choices=["true", "false"], default=argparse.SUPPRESS if default_suppress else "true",
                        help="Save raw PubChem RDF-REST responses locally (default: true).")
    parser.add_argument("--save-extracted", type=str, choices=["true", "false"], default=argparse.SUPPRESS if default_suppress else "true",
                        help="Save extracted rows/nodes/rels locally (default: true).")
    parser.add_argument("--console-log-level", type=str, default=argparse.SUPPRESS if default_suppress else "INFO", help="Console log level (INFO/WARNING/ERROR).")
    parser.add_argument("--file-log-level", type=str, default=argparse.SUPPRESS if default_suppress else "DEBUG", help="Log file level (DEBUG/INFO/WARNING/ERROR).")

    # Plugins
    parser.add_argument("--plugins", nargs="*", default=default,
                        help="Plugin names (e.g., molgraph embeddings uniprot) or full paths (module:callable).")


def build_argparser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="pring", description="PRING: build Neo4j graph from PubChem RDF (REST/FTP) + plugins.")
    _add_shared_args(ap, default_suppress=False)

    sub = ap.add_subparsers(dest="cmd", required=True)
    build = sub.add_parser(
        "build",
        help="Build KG according to provided inputs and caps.",
        description="Build KG according to provided inputs and caps.",
    )
    _add_shared_args(build, default_suppress=True)

    demo = sub.add_parser(
        "demo",
        help="Load a tiny demo graph (sanity check).",
        description="Load a tiny demo graph (sanity check).",
    )
    _add_shared_args(demo, default_suppress=True)

    schema = sub.add_parser(
        "schema",
        help="Create Neo4j constraints for node keys.",
        description="Create Neo4j constraints for node keys.",
    )
    _add_shared_args(schema, default_suppress=True)
    return ap


def _demo_rows() -> List[PubChemRow]:
    return [
        PubChemRow(kind="compound", data={"cid": 2244, "name": "caffeine", "smiles": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C"}),
        PubChemRow(kind="substance", data={"sid": 123, "cid": 2244, "source_id": "demo", "source_name": "Demo source"}),
        PubChemRow(kind="bioassay", data={"aid": 1, "name": "Demo assay"}),
        PubChemRow(kind="measuregroup", data={"mg_id": "mg:1", "aid": 1, "protein_id": "P12345"}),
        PubChemRow(kind="endpoint", data={"endpoint_id": "ep:1", "aid": 1, "mg_id": "mg:1", "sid": 123, "type": "IC50", "value": 3.2, "unit": "uM", "outcome": "Active"}),
    ]


def main(argv: Optional[List[str]] = None) -> None:
    args = build_argparser().parse_args(argv)
    settings = Settings.from_env()

    load_neo4j = (args.load_neo4j == "true") and (not args.dry_run)

    # Run folder + logging (early)
    run_id = args.run_id or datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(args.out_dir) / run_id
    store = RunStore(
        run_dir=run_dir,
        save_raw=(args.save_raw == "true"),
        save_extracted=(args.save_extracted == "true"),
    )
    log_path = setup_logging(
        log_dir=store.logs_dir,
        console_level=args.console_log_level,
        file_level=args.file_log_level,
    )

    # Override settings from CLI
    if args.schema_dot:
        settings = settings.with_overrides(schema_dot_path=Path(args.schema_dot))
    if args.batch_size:
        settings = settings.with_overrides(batch_size=int(args.batch_size))
    if args.cache_dir:
        settings = settings.with_overrides(cache_dir=Path(args.cache_dir))
    else:
        # Default cache dir per run (keeps thesis runs reproducible)
        settings = settings.with_overrides(cache_dir=store.http_cache_dir)

    # RDF REST overrides
    if args.rest_min_delay_s is not None or args.rest_max_delay_s is not None or args.rest_honor_throttling is not None:
        rr = settings.rdf_rest
        rr_kwargs = dict(
            base_url=rr.base_url,
            timeout_s=rr.timeout_s,
            max_retries=rr.max_retries,
            user_agent=rr.user_agent,
            min_delay_s=rr.min_delay_s,
            max_delay_s=rr.max_delay_s,
            honor_throttling_headers=rr.honor_throttling_headers,
        )
        if args.rest_min_delay_s is not None:
            rr_kwargs["min_delay_s"] = float(args.rest_min_delay_s)
        if args.rest_max_delay_s is not None:
            rr_kwargs["max_delay_s"] = float(args.rest_max_delay_s)
        if args.rest_honor_throttling is not None:
            rr_kwargs["honor_throttling_headers"] = (args.rest_honor_throttling == "true")
        settings = settings.with_overrides(rdf_rest=rr.__class__(**rr_kwargs))

    # SPARQL endpoint overrides
    if args.sparql_endpoint or args.sparql_timeout_s:
        sp = settings.sparql
        sp_kwargs = dict(endpoint_url=sp.endpoint_url, timeout_s=sp.timeout_s, max_retries=sp.max_retries, user_agent=sp.user_agent)
        if args.sparql_endpoint:
            sp_kwargs["endpoint_url"] = args.sparql_endpoint
        if args.sparql_timeout_s is not None:
            sp_kwargs["timeout_s"] = float(args.sparql_timeout_s)
        settings = settings.with_overrides(sparql=sp.__class__(**sp_kwargs))

    # Neo4j overrides
    neo = settings.neo4j
    neo_kwargs = dict(uri=neo.uri, user=neo.user, password=neo.password, database=neo.database,
                      encrypted=neo.encrypted, max_connection_lifetime=neo.max_connection_lifetime,
                      max_connection_pool_size=neo.max_connection_pool_size, connection_timeout=neo.connection_timeout)
    if args.neo4j_uri: neo_kwargs["uri"] = args.neo4j_uri
    if args.neo4j_user: neo_kwargs["user"] = args.neo4j_user
    if args.neo4j_password: neo_kwargs["password"] = args.neo4j_password
    if args.neo4j_db: neo_kwargs["database"] = args.neo4j_db
    settings = settings.with_overrides(neo4j=settings.neo4j.__class__(**neo_kwargs))

    # Flags / caps overrides
    flags = settings.flags
    if args.include_textmining is not None:
        flags = flags.__class__(
            include_textmining=(args.include_textmining == "true"),
            include_optional_context=flags.include_optional_context,
            include_endpoint_metadata=getattr(flags, "include_endpoint_metadata", True),
            include_endpoint_references=getattr(flags, "include_endpoint_references", False),
            taxids=getattr(flags, "taxids", None),
        )
    if args.include_optional_context is not None:
        flags = flags.__class__(
            include_textmining=flags.include_textmining,
            include_optional_context=(args.include_optional_context == "true"),
            include_endpoint_metadata=getattr(flags, "include_endpoint_metadata", True),
            include_endpoint_references=getattr(flags, "include_endpoint_references", False),
            taxids=getattr(flags, "taxids", None),
        )
    if args.include_endpoint_metadata is not None:
        flags = flags.__class__(
            include_textmining=flags.include_textmining,
            include_optional_context=flags.include_optional_context,
            include_endpoint_metadata=(args.include_endpoint_metadata == "true"),
            include_endpoint_references=getattr(flags, "include_endpoint_references", False),
            taxids=getattr(flags, "taxids", None),
        )
    if args.include_endpoint_references is not None:
        flags = flags.__class__(
            include_textmining=flags.include_textmining,
            include_optional_context=flags.include_optional_context,
            include_endpoint_metadata=getattr(flags, "include_endpoint_metadata", True),
            include_endpoint_references=(args.include_endpoint_references == "true"),
            taxids=getattr(flags, "taxids", None),
        )

    # Taxonomy override (applies to evidence filtering + symbol->gene resolution)
    if args.taxid is not None:
        from pring.config import _parse_taxids
        taxids = _parse_taxids(args.taxid)
        flags = flags.__class__(
            include_textmining=flags.include_textmining,
            include_optional_context=flags.include_optional_context,
            include_endpoint_metadata=getattr(flags, "include_endpoint_metadata", True),
            include_endpoint_references=getattr(flags, "include_endpoint_references", False),
            taxids=taxids,
        )

    caps = settings.caps.__class__(
        max_compounds_per_target=settings.caps.max_compounds_per_target if args.max_compounds_per_target is None else _parse_int_or_none(args.max_compounds_per_target),
        max_targets_per_compound=settings.caps.max_targets_per_compound if args.max_targets_per_compound is None else _parse_int_or_none(args.max_targets_per_compound),
        max_substances_per_compound=settings.caps.max_substances_per_compound if args.max_substances_per_compound is None else _parse_int_or_none(args.max_substances_per_compound),
        max_measuregroups_per_target=settings.caps.max_measuregroups_per_target if args.max_measuregroups_per_target is None else _parse_int_or_none(args.max_measuregroups_per_target),
        max_measuregroups_per_compound=settings.caps.max_measuregroups_per_compound if args.max_measuregroups_per_compound is None else _parse_int_or_none(args.max_measuregroups_per_compound),
        max_endpoints_per_pair=settings.caps.max_endpoints_per_pair if args.max_endpoints_per_pair is None else _parse_int_or_none(args.max_endpoints_per_pair),
    )
    settings = settings.with_overrides(flags=flags, caps=caps)

    # Plugins
    plugin_args = args.plugins or []
    plugin_paths = normalize_plugin_list(plugin_args)
    settings = settings.with_overrides(enabled_plugins=plugin_paths)

    if args.cmd == "schema":
        if not load_neo4j:
            log.info("Neo4j disabled (--load-neo4j=false or --dry-run). Nothing to do for schema.")
            return
        with Neo4jDriver(settings.neo4j) as driver:
            loader = Neo4jLoader(settings=settings, driver=driver)
            loader.validate_against_dot_schema()
            loader.ensure_schema()
            log.info("✅ Neo4j schema constraints applied.")
            return

    if args.cmd == "demo":
        rows = _demo_rows()
        nodes, rels = to_graph_records(rows)
        store.write_manifest({
            "run_id": run_id,
            "started_at": datetime.now().isoformat(),
            "mode": "demo",
            "scope": "demo",
            "caps": settings.caps.__dict__,
            "flags": settings.flags.__dict__,
            "plugins": settings.enabled_plugins,
            "neo4j": {
                "load_enabled": load_neo4j,
                "uri": settings.neo4j.uri,
                "user": settings.neo4j.user,
                "database": settings.neo4j.database,
            },
            "paths": {
                "run_dir": str(run_dir),
                "log_file": str(log_path),
                "cache_dir": str(settings.cache_dir),
            },
        })
        for row in rows:
            store.save_row(row.kind, row.data)
        store.save_nodes(nodes)
        store.save_relationships(rels)
        if not load_neo4j:
            log.info("Neo4j disabled: demo extracted (%d nodes, %d relationships) and artifacts saved in %s.", len(nodes), len(rels), run_dir)
            return
        with Neo4jDriver(settings.neo4j) as driver:
            loader = Neo4jLoader(settings=settings, driver=driver)
            loader.ensure_schema()
            loader.upsert_nodes(nodes)
            loader.upsert_relationships(rels)
        log.info("✅ Demo graph loaded.")
        return

    # Build command
    chem_ids = load_id_file(Path(args.chem_ids)) if args.chem_ids else []
    target_ids = load_id_file(Path(args.target_ids)) if args.target_ids else []

    mode = decide_mode(args.mode)
    scope = decide_scope(args.scope, chem_ids, target_ids)

    log.info("🧭 Plan: mode=%s scope=%s chem_ids=%d target_ids=%d", mode.value, scope.value, len(chem_ids), len(target_ids))
    log.info("caps=%s", settings.caps)
    log.info("flags=%s", settings.flags)
    if settings.enabled_plugins:
        log.info("plugins=%s", settings.enabled_plugins)

    # Save run manifest (redact Neo4j password)
    store.write_manifest({
        "run_id": run_id,
        "started_at": datetime.now().isoformat(),
        "mode": mode.value,
        "scope": scope.value,
        "inputs": {
            "chem_ids": str(args.chem_ids) if args.chem_ids else None,
            "target_ids": str(args.target_ids) if args.target_ids else None,
        },
        "caps": settings.caps.__dict__,
        "flags": settings.flags.__dict__,
        "plugins": settings.enabled_plugins,
        "neo4j": {
            "load_enabled": load_neo4j,
            "uri": settings.neo4j.uri,
            "user": settings.neo4j.user,
            "database": settings.neo4j.database,
        },
        "paths": {
            "run_dir": str(run_dir),
            "log_file": str(log_path),
            "cache_dir": str(settings.cache_dir),
        },
    })
    log.info("Run dir: %s", run_dir)
    log.info("Log file: %s", log_path)

    # Extraction
    rows: List[PubChemRow] = []
    effective_mode = mode.value
    if mode == Mode.rdf_rest:
        rdfrest_cache = (settings.cache_dir / "rdfrest") if (args.save_raw == "true") else None
        client = PubChemRdfRestClient(settings.rdf_rest, cache_dir=rdfrest_cache)
        extractor = PubChemRdfRestExtractor(client)
        rest_error: Optional[Exception] = None
        try:
            rows = _collect_rows(extractor, scope, chem_ids, target_ids, settings, store)
        except Exception as exc:
            rest_error = exc
        finally:
            try:
                extractor.close()
            except Exception:
                pass
            client.close()

        if rest_error is not None:
            if args.prefer_sparql_fallback == "true" and _fallback_worth_trying(rest_error):
                log.warning("RDF REST extraction failed (%s). Falling back to SPARQL mirror.", rest_error)
                sparql_cache = (settings.cache_dir / "sparql") if (args.save_raw == "true") else None
                client = SparqlMirrorClient(settings.sparql, cache_dir=sparql_cache)
                extractor = PubChemSparqlMirrorExtractor(client)
                try:
                    rows = _collect_rows(extractor, scope, chem_ids, target_ids, settings, store)
                    effective_mode = "sparql-fallback"
                finally:
                    try:
                        extractor.close()
                    except Exception:
                        pass
                    client.close()
            else:
                raise rest_error
    elif mode == Mode.sparql:
        sparql_cache = (settings.cache_dir / "sparql") if (args.save_raw == "true") else None
        client = SparqlMirrorClient(settings.sparql, cache_dir=sparql_cache)
        extractor = PubChemSparqlMirrorExtractor(client)
        try:
            rows = _collect_rows(extractor, scope, chem_ids, target_ids, settings, store)
        finally:
            try:
                extractor.close()
            except Exception:
                pass
            client.close()
    else:
        raise NotImplementedError("FTP mode is not implemented in this starter (you can add bulk dump ingestion later).")

    # Plugins: executed after core extraction (still stubs until you implement)
    # Note: plugins can also be run as standalone passes that 'observe' Neo4j, but we keep it pure here.
    nodes, rels = to_graph_records(rows)

    if effective_mode != mode.value:
        log.info("effective_mode=%s", effective_mode)
    log.info("Extracted rows=%d -> nodes=%d rels=%d", len(rows), len(nodes), len(rels))
    store.save_nodes(nodes)
    store.save_relationships(rels)

    for plugin in load_plugins(settings.enabled_plugins):
        if not plugin.enabled(settings):
            continue
        for delta in plugin.run(settings):
            nodes.extend(delta.nodes)
            rels.extend(delta.rels)

    # Save final graph again so plugin-generated records are persisted even when Neo4j is disabled.
    store.save_nodes(nodes)
    store.save_relationships(rels)

    if not load_neo4j:
        log.info("✅ Neo4j disabled: extraction artifacts saved in %s", run_dir)
        return

    with Neo4jDriver(settings.neo4j) as driver:
        loader = Neo4jLoader(settings=settings, driver=driver)
        loader.validate_against_dot_schema()
        loader.ensure_schema()
        loader.upsert_nodes(nodes)
        loader.upsert_relationships(rels)

    log.info("✅ Loaded: %d nodes, %d relationships.", len(nodes), len(rels))


if __name__ == "__main__":
    main()
